package model;

public class Categoria {

    public int codigoCategoria;
    public String nome;

    public Categoria(int codigoCategoria, String nome) {
        this.codigoCategoria = codigoCategoria;
        this.nome = nome;
    }

    public int getCodigoCategoria() {
        return codigoCategoria;
    }

    public String getNome() {
        return nome;
    }
}
