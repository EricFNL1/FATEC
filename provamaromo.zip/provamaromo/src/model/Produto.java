package model;

public class Produto {

    public int codigo;
    public String nome;
    public double preco;
    public int quantidade;
    public Categoria categoria;

    public Produto(int codigo, String nome, double preco, int quantidade, Categoria categoria) {
        this.codigo = codigo;
        this.nome = nome;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categoria = categoria;
    }

    public void entradaEstoque(int qtd){
        quantidade+=qtd;
    }

    public void saidaEstoque(int qtd){
       if(qtd <= quantidade){
           quantidade-=qtd;
       }
       else{
           System.out.println("Sem parangas armazenadas");
       }
    }

    public int  getSaldo(){
        return quantidade;
    }

    public int getCodigo() {
        return codigo;
    }

    public String toString() {
        return "Código: " + codigo + "\nNome: " + nome + "\nPreço: " + preco + "\nQuantidade em Estoque: " + quantidade + "\nCategoria: " + categoria.getNome();
    }



}
