package model;

import java.util.ArrayList;
import java.util.Scanner;

public class GerenciarProduto {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        ArrayList<Produto> produtos = new ArrayList<>();
        ArrayList<Categoria> categorias = new ArrayList<>();
        int codigoProduto = 1;
        int codigoCategoria = 1;

        while (true) {
            System.out.println("===== Menu =====");
            System.out.println("1. Cadastrar categoria");
            System.out.println("2. Cadastrar produto");
            System.out.println("3. Dar entrada no produto no estoque");
            System.out.println("4. Dar saída do produto do estoque");
            System.out.println("5. Mostrar saldo disponível de todos os produtos");
            System.out.println("6. Sair");
            System.out.print("Escolha uma opção: ");

            int opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome da categoria: ");
                    String nomeCategoria = scanner.nextLine();
                    categorias.add(new Categoria(codigoCategoria++, nomeCategoria));
                    break;

                case 2:
                    System.out.print("Nome do produto: ");
                    String nomeProduto = scanner.nextLine();
                    System.out.print("Preço do produto: ");
                    double precoProduto = scanner.nextDouble();
                    System.out.print("Quantidade em estoque: ");
                    int quantidadeProduto = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Categorias disponíveis:");
                    for (Categoria categoria : categorias) {
                        System.out.println(categoria.getCodigoCategoria() + ". " + categoria.getNome());
                    }
                    System.out.print("Escolha a categoria do produto: ");
                    int codigoCategoriaProduto = scanner.nextInt();

                    Categoria categoriaProduto = null;
                    for (Categoria categoria : categorias) {
                        if (categoria.getCodigoCategoria() == codigoCategoriaProduto) {
                            categoriaProduto = categoria;
                            break;
                        }
                    }

                    if (categoriaProduto != null) {
                        produtos.add(new Produto(codigoProduto++, nomeProduto, precoProduto, quantidadeProduto, categoriaProduto));
                        System.out.println("Produto cadastrado com sucesso.");
                    } else {
                        System.out.println("Categoria não encontrada.");
                    }
                    break;

                case 3:
                    System.out.print("Digite o código do produto: ");
                    int codigoEntrada = scanner.nextInt();
                    System.out.print("Quantidade de entrada: ");
                    int quantidadeEntrada = scanner.nextInt();

                    for (Produto produto : produtos) {
                        if (produto.getCodigo() == codigoEntrada) {
                            produto.entradaEstoque(quantidadeEntrada);
                            System.out.println("Entrada de estoque realizada com sucesso.");
                            break;
                        }
                    }
                    break;

                case 4:
                    System.out.print("Digite o código do produto: ");
                    int codigoSaida = scanner.nextInt();
                    System.out.print("Quantidade de saída: ");
                    int quantidadeSaida = scanner.nextInt();

                    for (Produto produto : produtos) {
                        if (produto.getCodigo() == codigoSaida) {
                            produto.saidaEstoque(quantidadeSaida);
                            System.out.println("Saída de estoque realizada com sucesso.");
                            break;
                        }
                    }
                    break;

                case 5:
                    System.out.println("Saldo disponível de todos os produtos:");
                    for (Produto produto : produtos) {
                        System.out.println(produto);
                        System.out.println("--------------------");
                    }
                    break;

                case 6:
                    System.out.println("Saindo do programa.");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }
    }
}

